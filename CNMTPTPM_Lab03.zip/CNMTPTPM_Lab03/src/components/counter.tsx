"use client";

import { useState } from "react";

export default function Counter() {
  const [count, setCount] = useState(0);

  return (
    <div className="inline-flex items-center gap-4 rounded-xl border border-slate-200 bg-white p-3 shadow-sm">
      <button
        type="button"
        onClick={() => setCount((prev) => prev - 1)}
        className="h-10 w-10 rounded-lg bg-slate-100 text-xl font-bold transition-colors hover:bg-slate-200"
      >
        -
      </button>
      <span className="w-10 text-center text-2xl font-bold text-slate-800">{count}</span>
      <button
        type="button"
        onClick={() => setCount((prev) => prev + 1)}
        className="h-10 w-10 rounded-lg bg-blue-600 text-xl font-bold text-white transition-colors hover:bg-blue-700"
      >
        +
      </button>
    </div>
  );
}
