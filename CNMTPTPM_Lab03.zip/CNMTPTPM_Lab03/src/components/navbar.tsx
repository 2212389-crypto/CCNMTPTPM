import Link from "next/link";

const navItems = [
  { href: "/", label: "Trang chu" },
  { href: "/about", label: "Gioi thieu" },
  { href: "/blog", label: "Blog" },
  { href: "/projects", label: "Du an" },
  { href: "/guestbook", label: "Luu but" },
  { href: "/contact", label: "Lien he" },
];

export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 border-b border-white/60 bg-white/75 backdrop-blur-xl">
      <nav className="mx-auto flex w-full max-w-6xl items-center justify-between px-4 py-4">
        <Link href="/" className="group flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-sky-500 to-blue-600 text-sm font-bold text-white shadow-lg shadow-sky-200/70">
            TC
          </span>
          <div>
            <div className="text-sm uppercase tracking-[0.3em] text-slate-400">Portfolio</div>
            <div className="text-lg font-semibold text-slate-900 transition-colors group-hover:text-sky-600">
              Ngo Cong Thanh
            </div>
          </div>
        </Link>

        <ul className="flex flex-wrap items-center gap-2 text-sm text-slate-600 md:gap-3">
          {navItems.map((item) => (
            <li key={item.href}>
              <Link
                href={item.href}
                className="rounded-full px-4 py-2 transition-all hover:bg-sky-50 hover:text-sky-700"
              >
                {item.label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </header>
  );
}
