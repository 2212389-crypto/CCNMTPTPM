export default function Footer() {
  return (
    <footer className="mt-auto border-t border-white/70 bg-white/80 backdrop-blur">
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-3 px-4 py-6 text-center text-sm text-slate-500 md:flex-row md:items-center md:justify-between md:text-left">
        <p>© 2026 2212389 Đỗ Lâm Ngọc An Khang - Cong nghe moi trong PTPM</p>
        <div className="flex items-center justify-center gap-4">
          <a
            href="mailto:nguyenvana@sv.dlu.edu.vn"
            className="transition-colors hover:text-blue-600"
          >
            Email
          </a>
          <a
            href="https://github.com/nguyenvana"
            target="_blank"
            rel="noopener noreferrer"
            className="transition-colors hover:text-blue-600"
          >
            GitHub
          </a>
        </div>
      </div>
    </footer>
  );
}
