import { guestbookEntries } from "@/data/guestbook";
import GuestbookForm from "@/components/guestbook-form";
import DeleteButton from "@/components/delete-button";
import { Card, CardContent } from "@/components/ui/card";

export default function GuestbookPage() {
  const entries = guestbookEntries;

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-8 flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-sm font-medium uppercase tracking-[0.24em] text-sky-600">
            Guestbook
          </p>
          <h1 className="mt-2 text-3xl font-bold text-slate-950 md:text-4xl">
            Sổ lưu bút
          </h1>
        </div>
        <p className="max-w-xl text-slate-600">
          Hãy để lại lời nhắn cho tôi nhé!
        </p>
      </div>

      <GuestbookForm />

      {/* Danh sách lời nhắn */}
      <div className="space-y-4">
        <p className="text-sm text-slate-400">{entries.length} lời nhắn</p>
        {entries.map((entry) => (
          <Card key={entry.id}>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold text-slate-800">
                  {entry.name}
                </span>
                <div className="flex items-center gap-3">
                  <span className="text-xs text-slate-400">
                    {new Date(entry.createdAt).toLocaleDateString("vi-VN")}
                  </span>
                  <DeleteButton id={entry.id} />
                </div>
              </div>
              <p className="text-slate-600">{entry.message}</p>
            </CardContent>
          </Card>
        ))}
        {entries.length === 0 && (
          <p className="text-center text-slate-400 py-8">
            Chưa có lời nhắn nào. Hãy là người đầu tiên!
          </p>
        )}
      </div>
    </div>
  );
}
