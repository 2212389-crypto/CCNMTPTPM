import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Project {
  title: string;
  description: string;
  tech: string[];
  status: "Hoan thanh" | "Dang phat trien";
}

const projects: Project[] = [
  {
    title: "Website Portfolio",
    description: "Website ca nhan xay dung bang Next.js va Tailwind CSS",
    tech: ["Next.js", "Tailwind CSS", "TypeScript"],
    status: "Dang phat trien",
  },
  {
    title: "Ung dung Quan ly Cong viec",
    description: "Ung dung Todo App voi React va Local Storage",
    tech: ["React", "CSS Modules", "JavaScript"],
    status: "Hoan thanh",
  },
  {
    title: "API RESTful",
    description: "API quan ly san pham voi Node.js va Express",
    tech: ["Node.js", "Express", "MongoDB"],
    status: "Hoan thanh",
  },
  {
    title: "Chat Realtime",
    description: "Ung dung chat realtime voi Socket.IO",
    tech: ["React", "Socket.IO", "Node.js"],
    status: "Dang phat trien",
  },
];

export default function ProjectsPage() {
  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-12">
      <div className="mb-8 flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-sm font-medium uppercase tracking-[0.24em] text-sky-600">Projects</p>
          <h1 className="mt-2 text-3xl font-bold text-slate-950 md:text-4xl">Dự án</h1>
        </div>
        <p className="max-w-xl text-slate-600">
          Danh sách các project tiêu biểu, trình bày theo card để nhìn rõ trạng thái và stack sử dụng.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        {projects.map((project) => (
          <Card key={project.title} className="hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="flex items-center justify-between gap-2">
                <CardTitle className="text-lg">{project.title}</CardTitle>
                <Badge
                  variant={
                    project.status === "Hoan thanh" ? "default" : "secondary"
                  }
                >
                  {project.status}
                </Badge>
              </div>
              <CardDescription>{project.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {project.tech.map((tech) => (
                  <Badge key={tech} variant="outline">
                    {tech}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
