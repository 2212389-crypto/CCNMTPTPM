export default function BlogLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-12">
      <div className="flex flex-col gap-8 lg:flex-row">
        <div className="flex-1 rounded-[2rem] border border-white/70 bg-white/80 p-6 shadow-sm backdrop-blur md:p-8">{children}</div>

        <aside className="w-full shrink-0 lg:w-64">
          <div className="rounded-[2rem] border border-white/70 bg-gradient-to-br from-slate-950 to-sky-700 p-5 text-white shadow-lg shadow-slate-950/10">
            <h3 className="mb-3 font-semibold">Danh muc</h3>
            <ul className="space-y-2 text-sm text-sky-50/90">
              <li className="cursor-pointer transition-colors hover:text-white">
                Cong nghe
              </li>
              <li className="cursor-pointer transition-colors hover:text-white">
                Hoc tap
              </li>
              <li className="cursor-pointer transition-colors hover:text-white">
                Du an ca nhan
              </li>
              <li className="cursor-pointer transition-colors hover:text-white">
                Cuoc song
              </li>
            </ul>
          </div>
        </aside>
      </div>
    </div>
  );
}
