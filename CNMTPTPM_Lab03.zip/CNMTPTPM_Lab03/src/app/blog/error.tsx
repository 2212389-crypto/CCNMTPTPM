"use client";

export default function BlogError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div className="py-12 text-center">
      <h2 className="mb-4 text-2xl font-bold text-red-600">Da xay ra loi!</h2>
      <p className="mb-6 text-slate-600">
        {error.message || "Khong the tai noi dung blog. Vui long thu lai."}
      </p>
      <button
        type="button"
        onClick={() => reset()}
        className="rounded-lg bg-blue-600 px-6 py-2 text-white transition-colors hover:bg-blue-700"
      >
        Thu lai
      </button>
    </div>
  );
}
