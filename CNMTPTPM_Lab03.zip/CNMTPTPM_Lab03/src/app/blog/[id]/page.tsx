import Link from "next/link";
import { notFound } from "next/navigation";
import { Post, User } from "@/types/post";

interface BlogPostPageProps {
  params: Promise<{ id: string }>;
}

async function getPost(id: string): Promise<Post> {
  const res = await fetch(
    `https://jsonplaceholder.typicode.com/posts/${id}`
  );
  if (!res.ok) {
    notFound();
  }
  return res.json();
}

async function getUser(userId: number): Promise<User> {
  const res = await fetch(
    `https://jsonplaceholder.typicode.com/users/${userId}`
  );
  if (!res.ok) {
    throw new Error("Không thể tải thông tin tác giả");
  }
  return res.json();
}

export default async function BlogPostPage({ params }: BlogPostPageProps) {
  const { id } = await params;
  const post = await getPost(id);
  const author = await getUser(post.userId);

  return (
    <div>
      <Link
        href="/blog"
        className="mb-6 inline-flex items-center gap-2 text-sm font-medium text-sky-700 hover:underline"
      >
        &lt;- Quay lại danh sách
      </Link>

      <article>
        <h1 className="mb-6 text-3xl font-bold tracking-tight text-slate-950 md:text-5xl capitalize">
          {post.title}
        </h1>

        <div className="mb-6 flex items-center gap-3 text-sm text-slate-500">
          <span>Tác giả: <strong className="text-slate-700">{author.name}</strong></span>
          <span>•</span>
          <span>{author.email}</span>
        </div>

        <div className="prose mb-8 max-w-none whitespace-pre-line text-slate-700">
          {post.body}
        </div>

        <div className="border-t border-slate-200 pt-6">
          <h3 className="font-semibold mb-2">Về tác giả</h3>
          <p className="text-slate-600 text-sm">
            <strong>{author.name}</strong> (@{author.username}) — {author.company.name}
          </p>
          <p className="text-slate-500 text-sm">{author.company.catchPhrase}</p>
        </div>
      </article>
    </div>
  );
}
