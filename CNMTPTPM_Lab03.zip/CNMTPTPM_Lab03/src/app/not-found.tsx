import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto w-full max-w-5xl px-4 py-24 text-center">
      <h1 className="mb-4 text-6xl font-bold text-slate-300">404</h1>
      <h2 className="mb-4 text-2xl font-bold">Trang khong ton tai</h2>
      <p className="mb-8 text-slate-600">
        Xin loi, trang ban dang tim kiem khong co tren website nay.
      </p>
      <Link
        href="/"
        className="inline-block rounded-lg bg-blue-600 px-6 py-2 text-white transition-colors hover:bg-blue-700"
      >
        Ve trang chu
      </Link>
    </div>
  );
}
