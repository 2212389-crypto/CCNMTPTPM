import Link from "next/link";
import Counter from "@/components/counter";

export default function HomePage() {
  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-10 md:py-16">
      <section className="relative mb-16 overflow-hidden rounded-[2rem] border border-white/60 bg-white/70 px-6 py-12 shadow-[0_20px_80px_rgba(15,23,42,0.08)] backdrop-blur md:px-10 md:py-16">
        <div className="absolute -right-20 -top-20 h-56 w-56 rounded-full bg-sky-200/40 blur-3xl" />
        <div className="absolute -bottom-24 left-12 h-64 w-64 rounded-full bg-indigo-200/30 blur-3xl" />

        <div className="relative mx-auto max-w-3xl text-center">
          <div className="mx-auto mb-6 flex h-24 w-24 items-center justify-center rounded-3xl bg-gradient-to-br from-sky-500 to-blue-600 text-4xl font-bold text-white shadow-lg shadow-sky-200/70">
            T
          </div>

          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-sky-100 bg-sky-50 px-4 py-2 text-sm font-medium text-sky-700">
            Portfolio ca nhan • App Router • Tailwind CSS
          </div>

          <h1 className="mb-4 text-4xl font-bold tracking-tight text-slate-950 md:text-6xl">
            Xin chào! Tôi là <span className="text-sky-600">Ngô Công Thành</span>
          </h1>
          <p className="mx-auto mb-8 max-w-2xl text-lg leading-8 text-slate-600 md:text-xl">
            Sinh viên Công nghệ Thông tin tại Đại học Đà Lạt, yêu thích xây dựng giao
            diện web rõ ràng, hiện đại và giàu trải nghiệm.
          </p>

          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link
              href="/projects"
              className="rounded-full bg-slate-950 px-6 py-3 text-white shadow-lg shadow-slate-950/15 transition-all hover:-translate-y-0.5 hover:bg-slate-800"
            >
              Xem dự án
            </Link>
            <Link
              href="/contact"
              className="rounded-full border border-slate-200 bg-white px-6 py-3 transition-all hover:-translate-y-0.5 hover:border-sky-200 hover:bg-sky-50"
            >
              Liên hệ
            </Link>
          </div>
        </div>
      </section>

      <section className="mb-16 grid gap-6 md:grid-cols-3">
        <div className="rounded-3xl border border-white/70 bg-white/80 p-6 shadow-sm backdrop-blur">
          <div className="text-sm font-medium uppercase tracking-[0.24em] text-sky-600">Tập trung</div>
          <div className="mt-2 text-3xl font-bold text-slate-900">UI rõ ràng</div>
          <p className="mt-3 text-slate-600">Thiết kế ưu tiên khoảng trắng, nhịp đọc và độ tương phản tốt.</p>
        </div>
        <div className="rounded-3xl border border-white/70 bg-white/80 p-6 shadow-sm backdrop-blur">
          <div className="text-sm font-medium uppercase tracking-[0.24em] text-sky-600">Công nghệ</div>
          <div className="mt-2 text-3xl font-bold text-slate-900">Next.js</div>
          <p className="mt-3 text-slate-600">Tổ chức routing theo App Router, tối ưu cho bài thực hành và dự án thực tế.</p>
        </div>
        <div className="rounded-3xl border border-white/70 bg-white/80 p-6 shadow-sm backdrop-blur">
          <div className="text-sm font-medium uppercase tracking-[0.24em] text-sky-600">Mục tiêu</div>
          <div className="mt-2 text-3xl font-bold text-slate-900">Sẵn sàng nộp bài</div>
          <p className="mt-3 text-slate-600">Có đủ trang, dynamic route, loading, error boundary và component tương tác.</p>
        </div>
      </section>

      <section className="mb-16 rounded-[2rem] border border-white/70 bg-white/80 p-6 shadow-sm backdrop-blur md:p-8">
        <div className="mb-6 flex items-end justify-between gap-4">
          <div>
            <p className="text-sm font-medium uppercase tracking-[0.24em] text-sky-600">Kỹ năng</p>
            <h2 className="mt-2 text-2xl font-bold text-slate-900">Stack hiện tại</h2>
          </div>
          <span className="rounded-full bg-slate-100 px-3 py-1 text-sm text-slate-600">Responsive grid</span>
        </div>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {[
            "JavaScript",
            "TypeScript",
            "React",
            "Next.js",
            "Tailwind CSS",
            "Node.js",
            "Git",
            "SQL",
          ].map((skill) => (
            <div
              key={skill}
              className="rounded-2xl border border-slate-100 bg-slate-50/80 p-4 text-center font-medium text-slate-700 transition-all hover:-translate-y-0.5 hover:border-sky-200 hover:bg-sky-50 hover:text-sky-700"
            >
              {skill}
            </div>
          ))}
        </div>
      </section>

      <section className="mb-16 grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
        <div className="rounded-[2rem] border border-white/70 bg-white/80 p-8 shadow-sm backdrop-blur">
          <p className="text-sm font-medium uppercase tracking-[0.24em] text-sky-600">Tương tác</p>
          <h2 className="mt-2 text-2xl font-bold text-slate-900">Client Component Demo</h2>
          <p className="mt-3 max-w-xl text-slate-600">Bộ đếm sử dụng useState để minh họa component phía client trong Next.js.</p>
          <div className="mt-6">
            <Counter />
          </div>
        </div>

        <div className="rounded-[2rem] border border-sky-100 bg-gradient-to-br from-sky-600 to-blue-700 p-8 text-white shadow-lg shadow-sky-200/50">
          <p className="text-sm font-medium uppercase tracking-[0.24em] text-sky-100">Tóm tắt</p>
          <h2 className="mt-2 text-2xl font-bold">Giao diện sạch hơn, sáng hơn</h2>
          <p className="mt-3 text-sky-50/90">
            Tông màu sáng, card bo tròn, hiệu ứng nổi nhẹ và bố cục có nhịp giúp web trông chuyên nghiệp hơn.
          </p>
          <div className="mt-6 flex flex-wrap gap-3 text-sm">
            <span className="rounded-full bg-white/15 px-3 py-1">Glass nav</span>
            <span className="rounded-full bg-white/15 px-3 py-1">Gradient hero</span>
            <span className="rounded-full bg-white/15 px-3 py-1">Soft cards</span>
          </div>
        </div>
      </section>

      <section className="rounded-[2rem] border border-slate-100 bg-white/85 p-8 text-center shadow-sm backdrop-blur">
        <h2 className="mb-3 text-2xl font-bold text-slate-900">Đọc blog của tôi</h2>
        <p className="mx-auto mb-6 max-w-2xl text-slate-600">
          Chia sẻ kiến thức và kinh nghiệm về lập trình, công nghệ, cùng một số ghi chú thực hành Next.js.
        </p>
        <Link
          href="/blog"
          className="inline-flex items-center gap-2 rounded-full bg-slate-950 px-6 py-3 font-semibold text-white transition-all hover:-translate-y-0.5 hover:bg-slate-800"
        >
          Xem blog -&gt;
        </Link>
      </section>
    </div>
  );
}
