export default function AboutPage() {
  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-12">
      <div className="rounded-[2rem] border border-white/70 bg-white/80 p-8 shadow-sm backdrop-blur md:p-10">
        <div className="mb-6 inline-flex rounded-full bg-sky-50 px-4 py-2 text-sm font-medium text-sky-700">
          About me
        </div>

        <h1 className="mb-6 text-3xl font-bold text-slate-950 md:text-4xl">Giới thiệu</h1>

        <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr] lg:items-start">
          <div className="space-y-5 text-slate-700">
            <p>
              Xin chào! Tôi là <strong>Ngô Công Thành</strong>, sinh viên năm 4 ngành
              Công nghệ Thông tin tại Đại học Đà Lạt.
            </p>
            <p>
              Tôi thích xây dựng giao diện web có trải nghiệm tốt, dễ đọc và có tính hệ
              thống. Mục tiêu của tôi là kết hợp thiết kế rõ ràng với mã nguồn gọn gàng.
            </p>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="rounded-2xl bg-slate-50 p-5">
                <div className="text-sm font-medium uppercase tracking-[0.24em] text-sky-600">Hướng phát triển</div>
                <p className="mt-2 font-semibold text-slate-900">Frontend & Product UI</p>
              </div>
              <div className="rounded-2xl bg-slate-50 p-5">
                <div className="text-sm font-medium uppercase tracking-[0.24em] text-sky-600">Phong cách làm việc</div>
                <p className="mt-2 font-semibold text-slate-900">Rõ ràng, có cấu trúc</p>
              </div>
            </div>
          </div>

          <div className="rounded-3xl bg-gradient-to-br from-sky-600 to-blue-700 p-8 text-white shadow-lg shadow-sky-200/50">
            <h2 className="text-2xl font-bold">Kỹ năng</h2>
            <ul className="mt-5 space-y-3 text-sky-50/95">
              <li>JavaScript / TypeScript</li>
              <li>React va Next.js</li>
              <li>Tailwind CSS</li>
              <li>Git va GitHub</li>
              <li>SQL va PostgreSQL</li>
            </ul>

            <div className="mt-8 rounded-2xl bg-white/10 p-5 backdrop-blur-sm">
              <p className="text-sm uppercase tracking-[0.24em] text-sky-100">Học vấn</p>
              <p className="mt-2 font-semibold">Đại học Đà Lạt</p>
              <p className="text-sky-50/90">Cử nhân Công nghệ Thông tin (2022 - 2026)</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
