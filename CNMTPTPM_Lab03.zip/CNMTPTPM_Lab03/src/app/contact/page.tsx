"use client";
import { useActionState } from "react";
import { sendContactMessage, ContactFormState } from "./actions";

const initialState: ContactFormState = {
  success: false,
};

export default function ContactPage() {
  const [state, formAction, isPending] = useActionState(
    sendContactMessage,
    initialState
  );

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-12">
      <div className="rounded-[2rem] border border-white/70 bg-white/80 p-8 shadow-sm backdrop-blur md:p-10">
        <div className="mb-6 inline-flex rounded-full bg-sky-50 px-4 py-2 text-sm font-medium text-sky-700">
          Contact
        </div>

        <h1 className="mb-6 text-3xl font-bold text-slate-950 md:text-4xl">Liên hệ</h1>

        <div className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr] lg:items-start">
          <div className="rounded-3xl bg-gradient-to-br from-slate-950 to-sky-700 p-8 text-white shadow-lg shadow-slate-950/10">
            <p className="text-sm uppercase tracking-[0.24em] text-sky-100">Thông tin nhanh</p>
            <p className="mt-4 text-2xl font-bold">Ngô Công Thành</p>
            <p className="mt-3 text-sky-50/90">
              Sẵn sàng trao đổi về học tập, dự án cá nhân và các công nghệ web hiện đại.
            </p>

            <div className="mt-8 space-y-4">
              <div>
                <p className="text-sm font-medium uppercase tracking-[0.24em] text-sky-100">Email</p>
                <a
                  href="mailto:nguyenvana@sv.dlu.edu.vn"
                  className="mt-2 block text-lg font-semibold text-sky-100 hover:text-white"
                >
                  nguyenvana@sv.dlu.edu.vn
                </a>
              </div>
              <div>
                <p className="text-sm font-medium uppercase tracking-[0.24em] text-sky-100">GitHub</p>
                <a
                  href="https://github.com/nguyenvana"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-2 block text-lg font-semibold text-sky-100 hover:text-white"
                >
                  github.com/nguyenvana
                </a>
              </div>
            </div>
          </div>

          <div>
            {state.success ? (
              <div className="rounded-2xl border border-green-200 bg-green-50 p-6 text-center">
                <h3 className="text-green-700 font-semibold text-lg mb-2">
                  Gửi thành công!
                </h3>
                <p className="text-green-600">
                  Cảm ơn bạn đã liên hệ. Tôi sẽ phản hồi sớm nhất có thể.
                </p>
              </div>
            ) : (
              <form action={formAction} className="space-y-4">
                <div>
                  <label
                    htmlFor="name"
                    className="block text-sm font-medium text-slate-700 mb-1"
                  >
                    Họ và tên
                  </label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    placeholder="Nguyễn Văn A"
                    required
                    className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                  {state.errors?.name && (
                    <p className="text-red-500 text-sm mt-1">
                      {state.errors.name[0]}
                    </p>
                  )}
                </div>

                <div>
                  <label
                    htmlFor="email"
                    className="block text-sm font-medium text-slate-700 mb-1"
                  >
                    Email
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="email@example.com"
                    required
                    className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                  {state.errors?.email && (
                    <p className="text-red-500 text-sm mt-1">
                      {state.errors.email[0]}
                    </p>
                  )}
                </div>

                <div>
                  <label
                    htmlFor="subject"
                    className="block text-sm font-medium text-slate-700 mb-1"
                  >
                    Tiêu đề
                  </label>
                  <input
                    id="subject"
                    name="subject"
                    type="text"
                    placeholder="Chủ đề bạn muốn trao đổi"
                    required
                    className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                  {state.errors?.subject && (
                    <p className="text-red-500 text-sm mt-1">
                      {state.errors.subject[0]}
                    </p>
                  )}
                </div>

                <div>
                  <label
                    htmlFor="message"
                    className="block text-sm font-medium text-slate-700 mb-1"
                  >
                    Nội dung
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    placeholder="Viết nội dung tin nhắn..."
                    required
                    rows={5}
                    className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500 resize-none"
                  />
                  {state.errors?.message && (
                    <p className="text-red-500 text-sm mt-1">
                      {state.errors.message[0]}
                    </p>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={isPending}
                  className="w-full bg-sky-600 text-white px-6 py-3 rounded-lg hover:bg-sky-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isPending ? "Đang gửi..." : "Gửi tin nhắn"}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
