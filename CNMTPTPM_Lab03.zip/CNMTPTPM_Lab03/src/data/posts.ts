export interface Post {
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  date: string;
  category: string;
  author: string;
}

export const posts: Post[] = [
  {
    slug: "gioi-thieu-nextjs",
    title: "Gioi thieu Next.js - Framework React pho bien",
    excerpt:
      "Tim hieu vi sao Next.js la lua chon hang dau cho phat trien web hien dai.",
    content: `Next.js la React framework duoc phat trien boi Vercel.

No cung cap Server-Side Rendering (SSR), Static Site Generation (SSG) va App Router.

Mot so uu diem noi bat:
- Routing tu dong dua tren cau truc thu muc
- Ho tro Server Components va Client Components
- Toi uu hinh anh, font va scripts
- Ho tro TypeScript san co`,
    date: "2026-01-15",
    category: "Cong nghe",
    author: "2212389 Đỗ Lâm Ngọc An Khang",
  },
  {
    slug: "hoc-tailwind-css",
    title: "Tailwind CSS - Cach tiep can utility-first",
    excerpt:
      "Kham pha phuong phap utility-first CSS va cach xay dung UI nhanh hon.",
    content: `Tailwind CSS la utility-first CSS framework.

Thay vi viet CSS tuy chinh cho tung component, ban ket hop cac class nho de tao giao dien.

Vi du:
- p-4: padding 16px
- rounded-lg: bo goc
- shadow-sm: do bong nhe

Uu diem la giu cho code nhat quan va nhanh khi prototype.`,
    date: "2026-01-20",
    category: "Cong nghe",
    author: "2212389 Đỗ Lâm Ngọc An Khang",
  },
  {
    slug: "kinh-nghiem-tu-hoc-lap-trinh",
    title: "Kinh nghiem tu hoc lap trinh hieu qua",
    excerpt: "Nhung bai hoc rut ra sau 3 nam tu hoc lap trinh tai dai hoc.",
    content: `Sau qua trinh hoc tap, minh rut ra 3 diem quan trong:

- Thuc hanh nhieu hon doc ly thuyet
- Xay dung du an thuc te de ghi nho kien thuc
- Tham gia cong dong de hoc nhanh hon

Lap trinh la ky nang can luyen tap lien tuc theo thoi gian.`,
    date: "2026-02-01",
    category: "Hoc tap",
    author: "2212389 Đỗ Lâm Ngọc An Khang",
  },
  {
    slug: "toi-uu-hieu-nang-nextjs-app-router",
    title: "Toi uu hieu nang voi App Router",
    excerpt: "Mot so meo de giam tai JavaScript va tang toc do tai trang.",
    content: `Khi dung App Router, hay uu tien Server Components cho noi dung tinh.

Ban chi nen tach nho phan can tuong tac thanh Client Components.

Ket hop them:
- loading.tsx de cai thien trai nghiem cho nguoi dung
- generateStaticParams de pre-render cac trang co the du doan`,
    date: "2026-02-12",
    category: "Cong nghe",
    author: "2212389 Đỗ Lâm Ngọc An Khang",
  },
  {
    slug: "ke-hoach-hoc-ky-cuoi",
    title: "Ke hoach hoc ky cuoi nganh CNTT",
    excerpt: "Cach can bang giua do an, thuc tap va viec hoc cong nghe moi.",
    content: `Hoc ky cuoi thuong rat ban.

Minh chia ke hoach theo tuan:
- 3 buoi cho do an
- 2 buoi cho mon hoc tren truong
- 2 buoi de cap nhat cong nghe

Cach nay giup giu nhip hoc deu va tranh qua tai.`,
    date: "2026-03-01",
    category: "Hoc tap",
    author: "2212389 Đỗ Lâm Ngọc An Khang",
  },
];

export function getPostBySlug(slug: string): Post | undefined {
  return posts.find((post) => post.slug === slug);
}
